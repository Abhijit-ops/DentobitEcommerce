<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PaymentModel extends Model
{
    protected $table='tbl_payment';
    protected $primaryKey='payment_id';
}
