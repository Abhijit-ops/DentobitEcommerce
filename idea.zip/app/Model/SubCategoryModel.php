<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubCategoryModel extends Model
{
    protected $table='subcategories';
    protected $primaryKey='id';
}
