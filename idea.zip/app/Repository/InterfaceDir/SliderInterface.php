<?php
namespace App\Repository\InterfaceDir;
interface SliderInterface
{
    public function getSlider($status);
}