<?php $__env->startSection('contents'); ?>
    <section id="login-reg-section" class="login-reg-section sec-ptb-100 clearfix">
        <div class="container">
            <div class="row justify-content-md-center">

                <!-- login-container - start -->
                <div class="col-lg-6 col-md-8 col-sm-12">
                    <div class="login-container">
                        <h2 class="form-title">login your account</h2>
                        <div class="social-accounts">
                            <span>Login with Social Account</span>
                            <ul>
                                <li><a href="#!"><i class="fab fa-facebook-square"></i> facebook</a></li>
                                <li><a href="#!"><i class="fab fa-twitter-square"></i> twitter</a></li>
                                <li><a href="#!"><i class="fab fa-google-plus-square"></i> google plus</a></li>
                            </ul>
                        </div>
                        <div class="login-form">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-item">
                                    <input type="text" id="user-name" placeholder="User Name" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                    <label class="form-item-btn" for="user-name">
                                        <i class="far fa-user"></i>
                                    </label>
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-item">
                                    <input type="password" id="user-pass" placeholder="Password"
                                           class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password"
                                    >
                                    <label class="form-item-btn" for="user-pass">
                                        <i class="fas fa-unlock-alt"></i>
                                    </label>
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="custom-form-check mb-30">
                                    <div class="row">

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="custom-form-check">
                                                <input type="checkbox"  name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                <label for="remember">Remember Me</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <?php if(Route::has('password.request')): ?>
                                                <a href="<?php echo e(route('password.request')); ?>" class="forgetpass-btn">
                                                    <?php echo e(__('Forgot Your Password?')); ?>

                                                </a>
                                            <?php endif; ?>

                                        </div>

                                    </div>
                                </div>
                                <button type="submit" class="custom-btn bg-past">login</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- login-container - end -->



            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\old\resources\views/auth/login.blade.php ENDPATH**/ ?>