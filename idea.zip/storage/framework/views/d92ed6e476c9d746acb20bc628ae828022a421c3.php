<?php $__env->startSection('contents'); ?>
    <section id="checkout-section" class="checkout-section sec-ptb-60 clearfix">
        <div class="container">
            <div class="row justify-content-md-center">
                <h2>Your Order ID <strong>DBE_<?php echo e($cartData->order_id); ?></strong><br></h2>

            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/products/checkoutConfirm.blade.php ENDPATH**/ ?>