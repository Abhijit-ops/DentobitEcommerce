<?php $__env->startSection('contents'); ?>
    
    <!-- slider-section - start
            ================================================== -->
    <section id="slider-section" class="slider-section clearfix">

        <!-- slider-item - start -->
        <div class="slider-item" style="background-image: url(<?php echo e(url('images/slider/dentatlslider.png')); ?>);">
            <div class="overlay-white sec-ptb-60">
                <div class="container">
                    <div class="row justify-content-center">

                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="slider-content">

                                <div class="mb-15">
                                    <h1 class="m-0">vr gear</h1>
                                    <h3 class="m-0">Capture life in high-definition</h3>
                                </div>

                                <div class="mb-30">
                                    <h4><strong class="color-pure-red">Save $160</strong> When you purchase </h4>
                                    <h2>Gear 360 Camera</h2>
                                    <h5 class="color-black">For $199.99</h5>
                                </div>

                                <a href="product-details.html" class="custom-btn bg-green">shop now</a>

                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="slider-item-image">
                                <img src="<?php echo e(asset('images/fresh_breath.png')); ?>" alt="image_not_found">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- slider-item - end -->


    </section>
    <!-- slider-section - end
    ================================================== -->
    
    
    



    <!-- police-section - start
================================================== -->
    <section id="police-section" class="police-section clearfix">
        <div class="container">

            <div class="police-service-list ul-li">
                <ul class="clearfix">

                    <li>
							<span class="icon bg-green">
								<i class="flaticon-delivery"></i>
							</span>
                        <div class="content">
                            <h3>Free Shipping</h3>
                            <p class="m-0">
                                Free Shipping On All Order Or Order above $100
                            </p>
                        </div>
                    </li>

                    <li>
							<span class="icon bg-green">
								<i class="flaticon-money-bag"></i>
							</span>
                        <div class="content">
                            <h3>100% Money Guarantee</h3>
                            <p class="m-0">
                                Simply Return it With 30 Days For an Exchange.
                            </p>

                        </div>
                    </li>

                    <li>
							<span class="icon bg-green">
								<i class="flaticon-support"></i>
							</span>
                        <div class="content">
                            <h3>Support 24/7</h3>
                            <p class="m-0">
                                Contact Us 24 Hours a Day 7 Days a Week
                            </p>
                        </div>
                    </li>

                    <li>
							<span class="icon bg-green">
								<i class="flaticon-pay"></i>
							</span>
                        <div class="content">
                            <h3>Payment Method</h3>
                            <p class="m-0">
                                We Ensure Secure Payment With PEV
                            </p>
                        </div>
                    </li>

                </ul>
            </div>

        </div>
    </section>
    <!-- police-section - end
    ================================================== -->





    <!-- promotion-section - start
    ================================================== -->
    <div class="promotion-section clearfix">
        <div class="container">
            <div class="row">

                <!-- promotion-item - start -->
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="promotion-item">
                        <a href="product-details.html" class="promotion-img">
                            <img src="<?php echo e(asset('images/promotion/digital/img-1.jpg')); ?>" alt="image_not_found">
                        </a>
                    </div>
                </div>
                <!-- promotion-item - end -->

                <!-- promotion-item - start -->
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="promotion-item">
                        <a href="product-details.html" class="promotion-img">
                            <img src="<?php echo e(asset('images/promotion/digital/img-2.jpg')); ?>" alt="image_not_found">
                        </a>
                    </div>
                </div>
                <!-- promotion-item - end -->

            </div>
        </div>
    </div>
    <!-- promotion-section - end
    ================================================== -->





    <!-- featured-section - start
    ================================================== -->
    <div id="featured-section" class="featured-section sec-ptb-60 clearfix">

        <div class="featured-container mb-30">
            <div class="container">
                <ul class="nav digital-featured-nav">
                    <li><a class="active" data-toggle="tab" href="#featured">featured</a></li>
                    <li><a data-toggle="tab" href="#best-seller">Best Seller</a></li>
                    <li><a data-toggle="tab" href="#top-rated">Top Rated</a></li>
                </ul>
            </div>

            <div class="tab-content">
                <!-- tab-pane (featured) - start -->
                <div id="featured" class="tab-pane fade in active show">
                    <div class="container">
                        <div class="row">
                            <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-primary">new</li>
                                            <li class="bg-danger">-50%</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="<?php echo e($featuredProduct->image); ?>" alt="<?php echo e($featuredProduct->name); ?>">
                                        <a href="<?php echo e(route('products.single',[$featuredProduct->id])); ?>" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                            quick view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="<?php echo e(route('products.single',[$featuredProduct->id])); ?>" class="item-title"><?php echo e($featuredProduct->name); ?></a>
                                        <div class="item-price">
                                            <strong class="color-black">$<?php echo e($featuredProduct->price); ?></strong>
                                            <del>$<?php echo e(($featuredProduct->price+$featuredProduct->price*(10/100))); ?></del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <form>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($featuredProduct->name); ?>" name="name" id="name_<?php echo e($featuredProduct->id); ?>">
                                            <input type="hidden" value="<?php echo e($featuredProduct->image); ?>" name="imgages" id="imgages_<?php echo e($featuredProduct->id); ?>">
                                            <input type="hidden" value="<?php echo e($featuredProduct->id); ?>" name="id" id="p_id_<?php echo e($featuredProduct->id); ?>">
                                            <input type="hidden" value="<?php echo e($featuredProduct->price); ?>" name="price" id="price_<?php echo e($featuredProduct->id); ?>">
                                            <input type="hidden" value="1" name="qty" id="qty_<?php echo e($featuredProduct->id); ?>">
                                            <button class="add-to-cart"  data-panel-id="<?php echo e($featuredProduct->id); ?>" onclick="storeToCart(this)"  type="button" >
                                                <i class="flaticon-shopper"></i>
                                                add to cart
                                            </button>
                                        </form>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <!-- tab-pane (featured) - end -->

                <!-- tab-pane (best-seller) - start -->
                <div id="best-seller" class="tab-pane fade">
                    <div class="container">
                        <div class="row">
                            <?php $__currentLoopData = $bestSellerProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestSeller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-primary"><?php echo e($bestSeller->checkStock); ?></li>
                                            <li class="bg-success">best seller</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="<?php echo e($bestSeller->image); ?>" alt="<?php echo e($bestSeller->name); ?>">
                                        <a href="<?php echo e(route('products.single',[$bestSeller->id])); ?>" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                             view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="<?php echo e(route('products.single',[$bestSeller->id])); ?>" class="item-title"><?php echo e($bestSeller->name); ?></a>
                                        <div class="item-price">
                                            <strong class="color-black">$<?php echo e($bestSeller->price); ?></strong>
                                            <del>$<?php echo e($bestSeller->price); ?></del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <?php if($bestSeller->checkStock!="Out Of Stock"): ?>
                                        <form>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($bestSeller->name); ?>" name="name" id="name_<?php echo e($bestSeller->id); ?>">
                                            <input type="hidden" value="<?php echo e($bestSeller->image); ?>" name="imgages" id="imgages_<?php echo e($bestSeller->id); ?>">
                                            <input type="hidden" value="<?php echo e($bestSeller->id); ?>" name="id" id="p_id_<?php echo e($bestSeller->id); ?>">
                                            <input type="hidden" value="<?php echo e($bestSeller->price); ?>" name="price" id="price_<?php echo e($bestSeller->id); ?>">
                                            <input type="hidden" value="1" name="qty" id="qty_<?php echo e($bestSeller->id); ?>">
                                            <button class="add-to-cart"  data-panel-id="<?php echo e($bestSeller->id); ?>" onclick="storeToCart(this)"  type="button" >
                                                <i class="flaticon-shopper"></i>
                                                add to cart
                                            </button>
                                        </form>
                                            <?php else: ?>
                                            <button class="add-to-cart-danger" type="button" >
                                                <i class="flaticon-shopper"></i>
                                               Out Of Stock
                                            </button>
                                        <?php endif; ?>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <!-- tab-pane (best-seller) - start -->

                <!-- tab-pane (top-rated) - start -->
                <div id="top-rated" class="tab-pane fade">
                    <div class="container">
                        <div class="row">

                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-danger">-50%</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="assets/images/featured/digital/digital-1.jpg" alt="image_not_found">
                                        <a href="#!" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                            quick view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="#!" class="item-title"> Sound P6 Stereo Headphones</a>
                                        <div class="item-price">
                                            <strong class="color-black">$129.00</strong>
                                            <del>$359.00</del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <a href="#!" class="add-to-cart">
                                            <i class="flaticon-shopping-basket"></i>
                                            add to cart
                                        </a>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-primary">new</li>
                                            <li class="bg-danger">-50%</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="assets/images/featured/digital/digital-2.jpg" alt="image_not_found">
                                        <a href="#!" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                            quick view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="#!" class="item-title">Smartphone 7 Plus 128GB Silver MN492</a>
                                        <div class="item-price">
                                            <strong class="color-black">$129.00</strong>
                                            <del>$359.00</del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <a href="#!" class="add-to-cart">
                                            <i class="flaticon-shopping-basket"></i>
                                            add to cart
                                        </a>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-danger">-50%</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="assets/images/featured/digital/digital-3.jpg" alt="image_not_found">
                                        <a href="#!" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                            quick view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="#!" class="item-title"> Acer Aspire E 15.6" Core i3 Laptop</a>
                                        <div class="item-price">
                                            <strong class="color-black">$129.00</strong>
                                            <del>$359.00</del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <a href="#!" class="add-to-cart">
                                            <i class="flaticon-shopping-basket"></i>
                                            add to cart
                                        </a>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="product-item">
                                    <div class="post-labels">
                                        <ul class="clearfix">
                                            <li class="bg-primary">new</li>
                                            <li class="bg-success">best seller</li>
                                        </ul>
                                    </div>
                                    <div class="image-container">
                                        <img src="assets/images/featured/digital/digital-4.jpg" alt="image_not_found">
                                        <a href="#!" class="quick-view">
                                            <i class="fas fa-eye"></i>
                                            quick view
                                        </a>
                                    </div>
                                    <div class="item-content text-center">
                                        <a href="#!" class="item-title">Smartphone 7 Plus 128GB Silver MN492</a>
                                        <div class="item-price">
                                            <strong class="color-black">$129.00</strong>
                                            <del>$359.00</del>
                                        </div>
                                    </div>
                                    <div class="hover-content">
                                        <div class="color-options ul-li-center mb-15">
                                            <ul>
                                                <li><a href="#!" class="color-1"></a></li>
                                                <li><a href="#!" class="color-2"></a></li>
                                                <li><a href="#!" class="color-3"></a></li>
                                            </ul>
                                        </div>
                                        <a href="#!" class="add-to-cart">
                                            <i class="flaticon-shopping-basket"></i>
                                            add to cart
                                        </a>
                                        <div class="product-meta ul-li-center">
                                            <ul class="clearfix">
                                                <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                                <li><a href="#!"><i class="flaticon-libra"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- tab-pane (top-rated) - start -->
            </div>
        </div>

        <div class="promotion-banner">
            <div class="container">
                <div class="row">

                    <!-- promotion-item - start -->
                    <div class="col-lg-4">
                        <div class="promotion-item">
                            <a href="product-details.html" class="promotion-img">
                                <img src="<?php echo e(asset('images/promotion/digital/img-3.jpg')); ?>" alt="image_not_found">
                            </a>
                        </div>
                    </div>
                    <!-- promotion-item - end -->

                    <!-- deal-item - start -->
                    <div class="col-lg-4">
                        <div class="deal-item text-center">
								<span class="deal-label">
									<img src="<?php echo e(asset('images/deal-label.png')); ?>" alt="image_not_found">
								</span>
                            <div class="image-container clearfix">
                                <img src="<?php echo e(asset('images/deals/digital/img-1.jpg')); ?>" alt="image_not_found">
                                <div class="countdown-timer">
                                    <ul class="countdown-list" data-countdown="2019/01/01"></ul>
                                </div>
                            </div>
                            <div class="item-content">

                                <div class="rateing-star">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                    <span><i>(05 review)</i></span>
                                </div>

                                <a href="#!" class="item-title">
                                    Samsung Gear 360 4K Spherical VR Camera (2018 Version)
                                </a>
                                <div class="item-price mb-15">
                                    <strong class="color-black">$129.00</strong>
                                    <del>$359.00</del>
                                </div>
                                <div class="sold-available clearfix">
                                    <span class="float-left">Available: 8</span>
                                    <span class="float-right">Already Sold: 20</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="35" aria-valuemin="0"
                                         aria-valuemax="100"></div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- deal-item - end -->

                    <!-- promotion-item - start -->
                    <div class="col-lg-4">
                        <div class="promotion-item">
                            <a href="product-details.html" class="promotion-img">
                                <img src="<?php echo e(asset('images/promotion/digital/img-4.jpg')); ?>" alt="image_not_found">
                            </a>
                        </div>
                    </div>
                    <!-- promotion-item - end -->

                </div>
            </div>
        </div>

    </div>
    <!-- featured-section - end
    ================================================== -->





    <!-- promotion-banner-section - start
    ================================================== -->
    <section id="promotion-banner-section" class="promotion-banner-section clearfix">
        <img src="<?php echo e(asset('images/promotion/digital/big-banner-1.jpg')); ?>" alt="image_not_found">
        <div class="digital-banner-content">

            <div class="item-details">
                <a href="#!" class="read-more"></a>
                <div class="details-bar">
                    <div class="image-container mb-15">
                        <img src="<?php echo e(asset('images/promotion/img-2.jpg')); ?>" alt="image_not_found">
                        <a href="#!" class="quick-view">
                            <i class="fas fa-eye"></i>
                            quick view
                        </a>
                    </div>
                    <a href="#!" class="item-title mb-15">
                        UHD Curved TV 78" 4K
                    </a>
                    <div class="item-price mb-15">
                        <strong class="color-black">$129.00</strong>
                        <del>$359.00</del>
                    </div>
                    <div class="color-options ul-li-center mb-15">
                        <ul>
                            <li><a href="#!" class="color-1"></a></li>
                            <li><a href="#!" class="color-2"></a></li>
                            <li><a href="#!" class="color-3"></a></li>
                        </ul>
                    </div>
                    <a href="#!" class="custom-btn bg-royal-blue">
                        <i class="flaticon-shopping-basket"></i>
                        add to cart
                    </a>
                </div>
            </div>

            <div class="item-details-2">
                <a href="#!" class="read-more"></a>
                <div class="details-bar">
                    <div class="image-container mb-15">
                        <img src="<?php echo e(asset('images/promotion/img-3.jpg')); ?>" alt="image_not_found">
                        <a href="#!" class="quick-view">
                            <i class="fas fa-eye"></i>
                            quick view
                        </a>
                    </div>
                    <a href="#!" class="item-title mb-15">
                        UHD Curved TV 78" 4K
                    </a>
                    <div class="item-price mb-15">
                        <strong class="color-black">$129.00</strong>
                        <del>$359.00</del>
                    </div>
                    <div class="color-options ul-li-center mb-15">
                        <ul>
                            <li><a href="#!" class="color-1"></a></li>
                            <li><a href="#!" class="color-2"></a></li>
                            <li><a href="#!" class="color-3"></a></li>
                        </ul>
                    </div>
                    <a href="#!" class="custom-btn bg-royal-blue">
                        <i class="flaticon-shopping-basket"></i>
                        add to cart
                    </a>
                </div>
            </div>

            <div class="main-content">
                <span>Curved HD TV</span>
                <h2><strong>The Features you walt,</strong>All in one place</h2>
                <p class="mb-15">
                    The curved display has a curvature level equivalent to that of a circle,
                    tracks the rounded shape os the eyes better
                </p>
                <a href="product-details.html" class="custom-btn bg-royal-blue">shop now</a>
            </div>

        </div>
    </section>
    <!-- promotion-banner-section - end
    ================================================== -->





    <!-- trending-section - start
    ================================================== -->
    <section id="trending-section" class="trending-section sec-ptb-60 clearfix">
        <div class="container">
            <div class="row justify-content-md-center">

                <!-- onsale-product - start -->
                <div class="col-lg-4 col-md-8 col-sm-12">
                    <div class="onsale-product">
                        <div class="section-title">
                            <h2>on sale</h2>
                        </div>
                        <div id="onsale-product-carousel" class="onsale-product-carousel owl-carousel owl-theme">

                            <div class="item text-center">
                                <div class="post-labels">
                                    <ul class="clearfix">
                                        <li class="bg-danger">-50%</li>
                                    </ul>
                                </div>
                                <div class="image-container mb-15">
                                    <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>" alt="image_not_found">
                                </div>
                                <a href="#!" class="item-title mb-15">Acer Aspire E 15.6" Core i3 Laptop</a>
                                <div class="item-price">
                                    <strong class="color-black">$129.00</strong>
                                    <del>$359.00</del>
                                </div>
                            </div>

                            <div class="item text-center">
                                <div class="post-labels">
                                    <ul class="clearfix">
                                        <li class="bg-primary">new</li>
                                        <li class="bg-danger">-50%</li>
                                    </ul>
                                </div>
                                <div class="image-container mb-15">
                                    <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>" alt="image_not_found">
                                </div>
                                <a href="#!" class="item-title mb-15">Acer Aspire E 15.6" Core i3 Laptop</a>
                                <div class="item-price">
                                    <strong class="color-black">$129.00</strong>
                                    <del>$359.00</del>
                                </div>
                            </div>

                            <div class="item text-center">
                                <div class="post-labels">
                                    <ul class="clearfix">
                                        <li class="bg-primary">new</li>
                                        <li class="bg-danger">-50%</li>
                                    </ul>
                                </div>
                                <div class="image-container mb-15">
                                    <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>" alt="image_not_found">
                                </div>
                                <a href="#!" class="item-title mb-15">Acer Aspire E 15.6" Core i3 Laptop</a>
                                <div class="item-price">
                                    <strong class="color-black">$129.00</strong>
                                    <del>$359.00</del>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- onsale-product - end -->

                <!-- products-tab - start -->
                <div class="col-lg-8 col-md-12 col-sm-12">
                    <div class="products-tab">

                        <div class="products-tab-nav ul-li-right">
                            <div class="section-title">
                                <h2>new arrivals</h2>
                            </div>
                            <ul class="nav">
                                <li><a class="active" data-toggle="tab" href="#all">all</a></li>
                                <li><a data-toggle="tab" href="#audio-video">audio & video</a></li>
                                <li><a data-toggle="tab" href="#smartphone">smartphone</a></li>
                                <li><a data-toggle="tab" href="#headphone">headphone</a></li>
                            </ul>
                        </div>

                        <div class="tab-content">
                            <div id="all" class="tab-pane fade in active show">
                                <div class="row">

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                    <li class="bg-success">best seller</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Galaxy Note8 Deepsea Blue will be
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Wireless Audio - 360 Speaker
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Samsung Gear 360 Spherical VR Camera
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Smartphone 7 Plus 128GB
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div id="audio-video" class="tab-pane fade">
                                <div class="row">

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                    <li class="bg-success">best seller</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Galaxy Note8 Deepsea Blue will be
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Wireless Audio - 360 Speaker
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Samsung Gear 360 Spherical VR Camera
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Smartphone 7 Plus 128GB
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div id="smartphone" class="tab-pane fade">
                                <div class="row">

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                    <li class="bg-success">best seller</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Galaxy Note8 Deepsea Blue will be
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Wireless Audio - 360 Speaker
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Samsung Gear 360 Spherical VR Camera
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Smartphone 7 Plus 128GB
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div id="headphone" class="tab-pane fade">
                                <div class="row">

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                    <li class="bg-success">best seller</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Galaxy Note8 Deepsea Blue will be
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Wireless Audio - 360 Speaker
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-danger">-50%</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Samsung Gear 360 Spherical VR Camera
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="product-item">
                                            <div class="post-labels">
                                                <ul class="clearfix">
                                                    <li class="bg-primary">new</li>
                                                </ul>
                                            </div>
                                            <div class="image-container">
                                                <img src="<?php echo e(asset('images/on-sale/digital/img-1.jpg')); ?>"
                                                     alt="image_not_found">
                                            </div>
                                            <div class="product-content">
                                                <a href="#!" class="product-title">
                                                    Smartphone 7 Plus 128GB
                                                </a>
                                                <div class="item-price">
                                                    <strong class="color-black">$129.00</strong>
                                                    <del>$359.00</del>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- products-tab - end -->

            </div>
        </div>
    </section>
    <!-- trending-section - end
    ================================================== -->



    </div>
    <!-- promotion-section - end
    ================================================== -->





    <!-- popular-section - start
    ================================================== -->
    <section id="popular-section" class="popular-section sec-ptb-60 clearfix">
        <div class="most-viewde-products">
            <div class="container">

                <!-- section-title - start -->
                <div class="section-title">
                    <h2>most viewed products</h2>
                </div>
                <!-- section-title - end -->

                <div class="row">
                    <!-- most-viewde-item - start -->
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="most-viewde-item text-center">
                            <div class="image-container mb-15">
                                <img src="<?php echo e(asset('images/most-viewed/digital/img-1.jpg')); ?>" alt="image_not_found">
                                <div class="absolute-cartview bg-royal-blue">
                                    <ul>
                                        <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                        <li><a href="#!"><i class="fas fa-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <a href="#!" class="item-title mb-15 color-royal-blue">Samsung Gear Camera</a>
                            <div class="item-price">
                                <strong class="color-black">$129.00</strong>
                                <del>$359.00</del>
                            </div>
                        </div>
                    </div>
                    <!-- most-viewde-item - end -->

                    <!-- most-viewde-item - start -->
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="most-viewde-item text-center">
                            <div class="image-container mb-15">
                                <img src="<?php echo e(asset('images/most-viewed/digital/img-1.jpg')); ?>" alt="image_not_found">
                                <div class="absolute-cartview bg-royal-blue">
                                    <ul>
                                        <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                        <li><a href="#!"><i class="fas fa-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <a href="#!" class="item-title mb-15 color-royal-blue">Acer Aspire E 15.6" Laptop</a>
                            <div class="item-price">
                                <strong class="color-black">$129.00</strong>
                                <del>$359.00</del>
                            </div>
                        </div>
                    </div>
                    <!-- most-viewde-item - end -->

                    <!-- most-viewde-item - start -->
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="most-viewde-item text-center">
                            <div class="image-container mb-15">
                                <img src="<?php echo e(asset('images/most-viewed/digital/img-1.jpg')); ?>" alt="image_not_found">
                                <div class="absolute-cartview bg-royal-blue">
                                    <ul>
                                        <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                        <li><a href="#!"><i class="fas fa-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <a href="#!" class="item-title mb-15 color-royal-blue">Wireless Audio - 360 Speaker</a>
                            <div class="item-price">
                                <strong class="color-black">$129.00</strong>
                                <del>$359.00</del>
                            </div>
                        </div>
                    </div>
                    <!-- most-viewde-item - end -->

                    <!-- most-viewde-item - start -->
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="most-viewde-item text-center">
                            <div class="image-container mb-15">
                                <img src="<?php echo e(asset('images/most-viewed/digital/img-1.jpg')); ?>" alt="image_not_found">
                                <div class="absolute-cartview bg-royal-blue">
                                    <ul>
                                        <li><a href="#!"><i class="flaticon-heart"></i></a></li>
                                        <li><a href="#!"><i class="fas fa-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <a href="#!" class="item-title mb-15 color-royal-blue">Android Wear 2.0, LG Watch Sport
                                (White)</a>
                            <div class="item-price">
                                <strong class="color-black">$129.00</strong>
                                <del>$359.00</del>
                            </div>
                        </div>
                    </div>
                    <!-- most-viewde-item - end -->
                </div>

            </div>
        </div>
    </section>
    <!-- popular-section - end
    ================================================== -->





    <!-- brand-logo-section - start
    ================================================== -->
    <div id="brand-logo-section" class="brand-logo-section clearfix">
        <div class="digital-brandlogo">
            <div class="container">
                <div id="brand-logo-carousel" class="brand-logo-carousel owl-carousel owl-theme">

                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>
                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>
                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>
                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>
                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>
                    <div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div><div class="item">
                        <a href="#!"><span><img src="<?php echo e(asset('images/brand/logo-1.png')); ?>" alt="image_not_found"></span></a>
                    </div>




                </div>
            </div>
        </div>
    </div>
    <!-- brand-logo-section - end
    ================================================== -->





    <!-- category-section - start
    ================================================== -->
    <section id="category-section" class="category-section sec-ptb-60 clearfix">
        <div class="container">

            <!-- section-title - start -->
            <div class="section-title mb-0">
                <h2>top categories this week</h2>
            </div>
            <!-- section-title - end -->

            <div class="digital-category-post">
                <div class="row">
                <?php $__currentLoopData = $navigationCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- post-item - start -->
                        <div class="col-lg-3 col-md-4 col-sm-12">
                            <div class="post-item">
                                <a href="#!" class="item-img">
                                    <img src="<?php echo e(asset('images/top-category/digital/img-1.jpg')); ?>" alt="image_not_found">
                                </a>
                                <span class="post-item-title"><?php echo e($category->name); ?></span>
                            </div>
                        </div>
                        <!-- post-item - end -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </section>
    <!-- category-section - end
    ================================================== -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/index.blade.php ENDPATH**/ ?>