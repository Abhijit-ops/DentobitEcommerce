<?php $__env->startSection('contents'); ?>
    <section id="login-reg-section" class="login-reg-section sec-ptb-100 clearfix">
        <div class="container">
            <div class="row justify-content-md-center">



                <!-- register-container - start -->
                <div class="col-lg-6 col-md-8 col-sm-12">
                    <div class="register-container">
                        <h2 class="form-title">Profile Updated</h2>
                        <div class="register-form">
                            <form method="POST" action="<?php echo e(route('user.updateProfile')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-item">
                                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           placeholder="Enter Your Name"  name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>
                                    <label class="form-item-btn" for="your-email">
                                        <i class="far fa-envelope"></i>
                                    </label>
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                <div class="form-item">
                                    <input id="email" type="number" placeholder="Enter Your Phone" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="phone" value="<?php echo e($user->phone); ?>"  autocomplete="phone">
                                    <label class="form-item-btn" for="your-email">
                                        <i class="fa fa-phone"></i>
                                    </label>
                                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e(phone); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-item">
                                    <input type="text" id="login-name" placeholder="User Name" value="<?php echo e($user->username); ?>">
                                    <label class="form-item-btn" for="login-name">
                                        <i class="far fa-user"></i>
                                    </label>
                                </div>
                                <div class="form-item">
                                    <input id="password" type="number" placeholder="Enter PostCode"
                                           class="form-control <?php if ($errors->has('post_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('post_code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="post_code"
                                           autocomplete="post_code" value="<?php echo e($user->post_code); ?>">

                                    <label class="form-item-btn" for="login-pass">
                                        <i class="fas fa-sort-numeric-down"></i>
                                    </label>
                                    <?php if ($errors->has('post_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('post_code'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-item">
                                    <textarea class="form-control" rows="5" name="billing_address" placeholder="Enter Address"
                                              style="resize: none"><?php echo e($user->billing_address); ?></textarea>
                                    <?php if ($errors->has('billing_address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_address'); ?>
                                    <p class="color-gplus-red text-left">Billing Address is requried</p>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>

                                <button type="submit" class="register-btn">Update now</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- register-container - end -->

            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/user/updateProfile.blade.php ENDPATH**/ ?>