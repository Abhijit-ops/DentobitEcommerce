<?php $__env->startSection('css'); ?>
    <style>
        .table thead>tr>td {
            border-bottom: none !important;
        }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
    <section id="contact-section" class="contact-section sec-ptb-60 clearfix">


        <div class="dashboard">
            <div class="container">
              <div class="row">
                  <div class="col-md-3 col-sm-12">
                      <ul class="list-group">
                          <li class="list-group-item"><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                          <li class="list-group-item"><a href="<?php echo e(route('user.orders')); ?>">Orders</a></li>
                          <li class="list-group-item"><a href="<?php echo e(route('user.updateProfileForm')); ?>">Update Profile</a></li>
                          <li class="list-group-item"><a href="#">Logout</a></li>

                      </ul>
                  </div>
                  <div class="col-md-9 col-sm-12">
                      <ul class="list-group">

                          <li class="list-group-item" >
                             <p class="text-right active"> <a href="<?php echo e(route('user.updateProfileForm')); ?>" class="color-green">Edit</a></p>
                              <table class="table mb-30">
                                  <tbody>
                                      <tr>
                                          <th>Name</th>
                                          <td class="text-left">
                                              <span><?php echo e(Auth::user()->name); ?></span>
                                          </td>
                                      </tr>
                                      <tr>
                                          <th>UserName</th>
                                          <td class="text-left" colspan="2">
                                              <span><?php echo e(Auth::user()->username); ?></span>
                                          </td>
                                      </tr>
                                      <tr>
                                          <th>Email</th>
                                          <td class="text-left" colspan="2">
                                              <span><?php echo e(Auth::user()->email); ?></span>
                                          </td>
                                      </tr>
                                      <tr>
                                          <th>Phone</th>
                                          <td class="text-left" colspan="2">
                                              <span><?php echo e(Auth::user()->phone); ?></span>
                                          </td>
                                      </tr>
                                      <tr>
                                          <th>Post Code</th>
                                          <td class="text-left" colspan="2">
                                              <span><?php echo e(Auth::user()->post_code); ?></span>
                                          </td>
                                      </tr>
                                      <tr>
                                          <th>Address</th>
                                          <td class="text-left" colspan="2">
                                              <span><?php echo e(Auth::user()->billing_address); ?></span>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                          </li>
                      </ul>
                  </div>
              </div>
            </div>
        </div>

    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/user/dashboard.blade.php ENDPATH**/ ?>