<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SliderModel extends Model
{
    protected $table='slider';
    protected $primaryKey='id';

}
