<?php $__env->startSection('contents'); ?>



    <!-- contact-section - start
		================================================== -->
    <section id="contact-section" class="contact-section sec-ptb-60 clearfix">


        <div class="contact-form text-center">
            <div class="container">

                <div class="section-title text-center">
                    <h2>Send a Message</h2>
                    <p>Your email address will not be published.</p>
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10 col-sm-12">
                        <form action="<?php echo e(route('contact.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-item">
                                        <input id="name" type="text" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>">
                                        <label for="name" class="form-item-btn">
                                            <i class="far fa-user"></i>
                                        </label>
                                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                        <p class="color-gplus-red text-left">name is requried</p>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-item">
                                        <input id="email" type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                        <label for="email" class="form-item-btn">
                                            <i class="far fa-envelope"></i>
                                        </label>
                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <p class="color-gplus-red text-left">Email is requried</p>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-item">
                                <input id="subject" type="text" placeholder="Subject" name="subject" value="<?php echo e(old('subject')); ?>">
                                <label for="subject" class="form-item-btn">
                                    <i class="far fa-file-alt"></i>
                                </label>
                            </div>

                            <div class="form-textarea clearfix">
                                <textarea id="comment-textarea" name="message"><?php echo e(old('message')); ?></textarea>
                                <?php if ($errors->has('message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('message'); ?>
                                <p class="color-gplus-red text-left">Message is requried</p>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                <div class="textarea-footer ul-li-right clearfix">
                                    <ul class="clearfix">

                                        <li><button type="submit" class="submit-btn">submit now</button></li>
                                    </ul>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- contact-section - end
    ================================================== -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/contact.blade.php ENDPATH**/ ?>