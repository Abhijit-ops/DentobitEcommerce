<?php $__env->startSection('contents'); ?>
    <section id="login-reg-section" class="login-reg-section sec-ptb-100 clearfix">
        <div class="container">
            <div class="row justify-content-md-center">



                <!-- register-container - start -->
                <div class="col-lg-6 col-md-8 col-sm-12">
                    <div class="register-container">
                        <h2 class="form-title">don't have an account? register now!</h2>
                        <div class="register-form">
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-item">
                                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           placeholder="Enter Your Name"  name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                    <label class="form-item-btn" for="your-email">
                                        <i class="far fa-envelope"></i>
                                    </label>
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>

                                <div class="form-item">
                                    <input id="email" type="email" placeholder="Enter Your Email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                    <label class="form-item-btn" for="your-email">
                                        <i class="far fa-envelope"></i>
                                    </label>
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-item">
                                    <input type="text" id="login-name" placeholder="User Name">
                                    <label class="form-item-btn" for="login-name">
                                        <i class="far fa-user"></i>
                                    </label>
                                </div>
                                <div class="form-item">
                                    <input id="password" type="password" placeholder="Enter Password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                    <label class="form-item-btn" for="login-pass">
                                        <i class="fas fa-unlock-alt"></i>
                                    </label>
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-item">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                    <label class="form-item-btn" for="login-pass">
                                        <i class="fas fa-unlock-alt"></i>
                                    </label>
                                </div>
                                <div class="custom-form-check mb-30">
                                    <input type="checkbox" id="agree" required>
                                    <label for="agree">I agree to <strong class="color-black">Terms & Conditions</strong></label>
                                </div>
                                <button type="submit" class="register-btn">register now</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- register-container - end -->

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dbitecommerce\new\resources\views/auth/register.blade.php ENDPATH**/ ?>