@include('Helper.Header')
@include('Helper.Navbar')

@yield('contents')
@include('Helper.Footer')